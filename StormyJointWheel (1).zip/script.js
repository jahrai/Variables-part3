//Const Variables

const name = 'Juan';



console.log(name);